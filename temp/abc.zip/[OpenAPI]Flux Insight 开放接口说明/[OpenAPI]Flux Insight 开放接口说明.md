# \[OpenAPI\]Flux Insight 开放接口说明

# 概述

Flux Insight OpenAPI 提供任务洞察、已上传产物、已采集历史版本、GUI 报告及执行 Trace 查询。各能力的数据来源与时效不同，不能统一视为 T\-1 数据或实时数据。

通用接入：生产 Base URL 为 https://flux\-insight\.byted\.org；以下路径统一加 /openapi/v1 前缀，HTTP Method 均为 POST。请求头携带 X\-Jwt\-Token 和 Content\-Type: application/json。

OpenAPI 使用 IAM access / access\_sensitive。默认频控 10 次/s，范围为接口 × 服务实例 × 已认证主体，可由部署配置调整。Task 列表采用 limit/cursor keyset 分页，无 total；raw/截图成功返回字节。

说明核对日期：2026\-10\-29。下表与更新章节依据 Insight Backend 50942ae、Helix b792f3c425 的本地源码；接口已在代码注册不等于对应生产版本已部署。本次未核验生产部署和 TCC 配置，尤其新版共享场景、分页与 Trace v2 的上线状态。

## 接口选择总览

|路径（POST /openapi/v1）|用途|主要入参|使用限制|
|---|---|---|---|
|/task|查任务列表、指标；单 ID 查详情|task\_id\_list / worker\_session\_id\_list / filters；limit、cursor；可选 Trace 模式|列表需 access；Trace 模式/任务原文需 access\_sensitive；列表不是实时执行状态|
|/task/changed/artifacts|列出最近已上传的产物文件|task\_id 或 worker\_session\_id，恰好一个|非历史快照；repos 仅 flux/changes 与 flux/\.local|
|/task/artifacts/raw|下载清单中的文件|同上 \+ path|成功返回字节；不支持任何非 null version\_id|
|/task/artifacts/versions|读取已采集的版本信息|task\_id 或 worker\_session\_id，恰好一个|依赖采集；多 Session 需明确选择；当前 comparisons 为 null|
|/task/artifacts/version\-diff|读取已采集的两版累计 diff|同上 \+ 一组完整物理版本或主对话版本区间|不是任意区间在线计算；缺区间/空 diff\_url 报错|
|/task/artifacts/gui\-test/case\-result|解析 GUI 报告的 caseResult|task\_id 或 worker\_session\_id，恰好一个|依赖旧采集；新 Worker 文件存在不代表此接口有数据|
|/task/artifacts/gui\-test/screenshots|下载旧采集截图|同上 \+ path 子串|首个匹配；成功返回图片字节|
|/trace/query|查询 Mongo 执行链、工具、模型、Token|task\_id 或 worker\_session\_id；include\_raw\_spans；compress；推荐合同头 2|Task 按 task\_id 定界；不回退 Fornax；超预算整体失败|
|/task/trace|分批读取大任务原文或会话消息|task\_id 或 standalone session\_id；action；ticket；cursor|需 access\_sensitive；先 inventory；不可把 worker\_session\_id 当 session\_id 别名|

常用顺序：查任务与指标 → /task；只理解对话 → 单 ID /task \+ messages\_only；看执行过程 → /trace/query 或单 ID /task \+ simplified；拿文件 → changed/artifacts 后按返回 path 调 raw；查历史 → versions / version\-diff，但先确认采集可用性。

本文后续依次说明环境、IAM 鉴权、快速开始、接口参数与返回、变更记录及联系渠道。

# 环境说明

|**环境**|**域名**|**必须请求头**|
|---|---|---|
|生产|https://flux\-insight\.byted\.org/|X\-Jwt\-Token|

# 鉴权

**请提前申请权限：**无论使用个人 JWT 还是服务账号 JWT，调用前都需先 IAM 申请 OpenAPI 调用权限

申请入口  👉 [IAM 权限申请](https://cloud.bytedance.net/iam/workorder/apply?mode=resource&resourceType=brn&resourceValue=brn%3A%3Aflux_insight_backend%3A%3A%3Aflux_insight_backend_openapi%3A21887750&resourceBrnTarget=&permission=&specifiedRoleName=&requestKey=&initialUserType=&initialUsername=&conditionName=&conditionExpression=&x-bc-region-id=bytedance&x-resource-account=public) （**如需TOS等敏感数据请更改申请角色**）

## 方式一：个人 JWT

使用个人身份的 JWT 调用，适合联调与自测（同样需先完成上述 IAM 权限申请）。Token 具有时效，失效后（返回 `2001 unauthorized`）重新获取即可。

## 方式二：服务账号 JWT

使用脚本多次访问，可以通过服务账号的 JWT 请求\(服务账号使用secret key请求，可以定期刷新\)

权限分级与返回内容

- access：OpenAPI 调用权限。未获 IAM 授权返回 2002 forbidden；JWT 缺失、失效或主体类型不支持返回 2001。2003 在常规 OpenAPI 链路表示限流。

- access\_sensitive：Task/Trace 敏感投影、任务 TOS 原文及共享 Trace 模式的读取权限。无此权限时 Task/Trace 按各自字段规则脱敏，Task 不读取或附带 tos\_detail；Task 的 include\_trace、simplified、messages\_only 和 /task/trace 被拒绝。

- 产物 raw、versions、diff、GUI 报告与截图当前只检查 access，没有额外 access\_sensitive gate；文件字节不做内容脱敏。不要将 Task 字段脱敏规则当成产物文件的脱敏保证。

- OpenAPI 的 IAM 权限与网页/内部 API 的 Kani 权限独立。带 AUTHZ\_\* 的错误按 HTTP 状态、data\.error\.code 和 retriable 判断，不能仅把数字 2003 当成可重试限流。

# 快速开始

```Bash
curl -X POST "https://flux-insight.byted.org/openapi/v1/task" \
  -H "Content-Type: application/json" \
  -H "X-Jwt-Token: <你的jwt token>" \
  -d '{
  "task_id_list": [
    "72212538607097487"
  ],
  "limit": 10
}'
```

```Bash
curl -X POST "https://flux-insight.byted.org/openapi/v1/task" \
  -H "Content-Type: application/json" \
  -H "X-Jwt-Token: <你的jwt token>" \
  -d '{
  "filters": {
    "query_and_or": "and",
    "filter_fields": [
      {
        "field_name": "created_by",
        "field_type": "string",
        "query_type": "in",
        "values": ["zhangsan", "lisi"]
      },
      {
        "field_name": "task_created_at",
        "field_type": "string",
        "query_type": "range",
        "values": ["2026-06-01 00:00:00", "2026-06-30 23:59:59"]
      }
    ]
  },
  "limit": 10
}'
```

# 接口详情

## Task 列表查询 · POST /openapi/v1/task

### 基本信息

|项目|说明|
|---|---|
|HTTP URL|https://\{domain\}/openapi/v1/task|
|HTTP Method|POST|
|频控限制|默认 10 次/s；接口 × 服务实例 × 已认证主体，按部署配置调整|

### 请求消息

#### 请求头

|**名称**|**类型**|**必填**|**描述**|
|---|---|---|---|
|X\-Jwt\-Token|string|是|调用凭证 token|
|Content\-Type|string|是|application/json|

#### 请求参数

|名称|类型|必填|描述|
|---|---|---|---|
|task\_id\_list|Array|否|真实 Flux Task ID 列表。元素为全数字字符串、单值 ≤64 字符，去重后 ≤200 个；不接受占位 0。ID 列表与 filters\.filter\_fields 不能同时为空。单 ID 在敏感权限下可附带可选 TOS 或 Trace 详情，见后文。|
|worker\_session\_id\_list|Array|否|主 Worker Session ID 列表，按表的 worker\_session\_id 精确查；standalone 行需用此字段。约束同 task\_id\_list。唯一映射到真实 Task 时也可附带任务 TOS；standalone 无任务快照。|
|filters|object|否|查询条件组，与 task\_id\_list、worker\_session\_id\_list 至少传一个|
|∟query\_and\_or|string|否|条件组之间的关系 and/or（默认 and）。⚠️ or 不支持多字段：多个 filter\_field 传 or 会返回 1003|
|∟filter\_fields|Array|否|过滤条件数组，最多 15 条|
|∟∟field\_name|string|是|条件字段名，须在支持列表内（见下方「filters\.filter\_fields 支持字段」），否则返回 1002|
|∟∟field\_type|string|是|条件字段类型，当前均为 string，须与字段规则匹配|
|∟∟query\_type|string|是|查询算子 in 或 range（取决于字段，见支持字段表）|
|∟∟values|Array|是|条件字段值数组，非空。in 时 1\~100 个、单值 ≤1024 字符；range 时恰 2 个 \[下界, 上界\]，任一端传空串表示不限，且下界不得大于上界|
|limit|int|否|单页条数，范围 1\~200，默认 50（单 id 详情查询上限降为 50）。越界返回 1004|
|cursor|string|否|keyset 分页游标，取上一页返回的 next\_cursor；首页留空。须为合法 base64url，非法返回 1004|
|include\_trace|boolean|否|默认 false；单 ID 查询附带共享场景 trace\_detail，需 access\_sensitive。开启后不附带 tos\_detail。|
|simplified|boolean|否|默认 false；隐含 include\_trace，返回简化执行视图，需 access\_sensitive。|
|messages\_only|boolean|否|默认 false；只返回共享场景的用户/助手正文，需 access\_sensitive；不能与 include\_trace 或 simplified 同传。|

##### filters\.filter\_fields 支持字段

|字段名|类型|支持条件类型|说明|
|---|---|---|---|
|created\_by|string|in|任务归属人（原 username 改名）。索引列，可单独使用|
|worker\_session\_id|string|in|主 worker 会话 ID（原 session\_id 改名，新表存储唯一键）。索引列，可单独使用|
|task\_status|string|in|任务状态过滤。索引列，可单独使用|
|row\_source|string|in|行来源，取值 `worker_task`（真实 task 行）/ `openapi_session`（standalone session 行）。索引列，可单独使用|
|task\_is\_completed|string|in|任务是否完成。索引列，可单独使用|
|task\_created\_at|string|range|任务创建时间，range 区间过滤（values\[0\] 下界、values\[1\] 上界，空串表示不限）。索引列，可单独使用|
|updated\_at|string|range|记录更新时间，range 区间过滤。索引列，可单独使用|
|task\_updated\_at|string|range|任务更新时间，range 区间过滤。⚠️ 无索引，必须与至少一个索引列同时使用|
|level\_1\_category|string|in|一级分类。⚠️ JSON 虚拟列，必须与至少一个索引列同时使用|
|level\_2\_category|string|in|二级分类。⚠️ JSON 虚拟列，必须与至少一个索引列同时使用|
|level\_3\_category|string|in|三级分类。⚠️ JSON 虚拟列，必须与至少一个索引列同时使用|
|source\_platform|string|in|来源平台。⚠️ JSON 虚拟列，必须与至少一个索引列同时使用|

##### 筛选算子与常用组合

**`values`**** 语义**

- `in` 与 `range` 两种算子（当前不支持 `eq`）。

- `in`：多值集合，`values` 是候选集合，例如 `values=["zhangsan","lisi"]`。

- `range`：区间筛选，`values[0]` 为下界，`values[1]` 为上界；任一位置传空字符串表示不设该边界，例如 `values=["100",""]` 表示 `>=100`，`values=["","300"]` 表示 `<=300`。

**典型业务组合**

- 查某个用户名下的任务：`{"field_name":"created_by","field_type":"string","query_type":"in","values":["zhangsan"]}`

- 查某段时间内创建的任务：`{"field_name":"task_created_at","field_type":"string","query_type":"range","values":["2026-06-01 00:00:00","2026-06-30 23:59:59"]}`

**注意事项**

- filter\_fields 默认按 AND 组合；query\_and\_or=or 仅支持单字段，多字段 or 返回 1003。需要多字段 OR 时拆成多次查询并由调用方合并去重。

#### 请求体示例

```JSON
{
  "task_id_list": ["80028064809062732", "80028064809062733"],
  "filters": {
    "query_and_or": "and",
    "filter_fields": [
      {"field_name": "created_by", "field_type": "string", "query_type": "in", "values": ["zhangsan"]},
      {"field_name": "task_created_at", "field_type": "string", "query_type": "range", "values": ["2026-06-01 00:00:00", "2026-06-30 23:59:59"]}
    ]
  },
  "limit": 50
}

```

#### 查询行为说明

**分页规则**

采用 keyset 游标分页：limit 默认 50、最大 200，单 ID 详情上限 50，越界返回 1004。首页 cursor 留空，下一页使用 next\_cursor 原值；服务查询 limit \+ 1 行判断 has\_more，并用本页最后一条实际返回记录生成游标，has\_more=false 时停止。排序为 task\_created\_at DESC、id DESC；不提供 total，也不提供跨请求冻结快照。

### 响应体

|名称|类型|描述|
|---|---|---|
|code|int|错误码，0 表示成功，非 0 表示失败|
|msg|string|错误信息描述；成功时固定为 success|
|data|object|成功时返回业务数据；失败时返回 \{\}|
|∟items|Array|任务 insight 列表，一行 = 一个 task（不再按 task\_id 聚合折叠）|
|∟∟task\_id|string|展示/路由主键：真实 task 为 task\_id；standalone openapi session（无 task）为 worker\_session\_id|
|∟∟id\_kind|string|标识上面 task\_id 的种类：task 或 session。两种都是全数字雪花 ID，靠 ID 本身无法区分，须读此字段|
|∟∟task|object|该行的字段对象。⚠️ 按数据库列白名单动态透出（非固定 schema），字段集随列表/详情投影不同；所有标量值均以字符串返回（含 bigint ID，避免精度丢失）。普通权限下部分归属人字段与敏感列会被脱敏|
|∟∟∟\<字段\>|string|task 内的具体列，如 task\_status、title、created\_by、task\_created\_at、input\_tokens 等，取值见「响应体示例」|
|∟page\_info|object|keyset 分页元信息|
|∟∟limit|int|本页请求的 limit（回显）|
|∟∟next\_cursor|string|下一页游标；无更多数据时可能省略|
|∟∟has\_more|bool|服务通过额外一行判断是否还有下一页；false 时停止翻页。|
|∟tos\_detail|object|可选任务归档原文。敏感权限、未开启 Trace 模式、恰好一个 Task/Worker Session ID 时读取；单 Session 必须唯一映射真实 Task。|
|∟∟task\_id|string|任务 ID|
|∟∟version|string|实际命中的归档版本 vN。由 tos\_credentials\.snapshotVersion 指定发现上限并向 v1 回退，不固定到 v14；v8→v9 为破坏性变更，按返回版本解析。|
|∟∟object\_key|string|TOS 存储对象路径 key|
|∟∟content\_base64|string|Base64 编码的归档原始字节；通常 gzip，存量兼容 plain。v15\+ 的引用对象由服务解析后返回内容对象字节。|
|∟∟content\_encoding|string|内容编码方式，固定 base64|
|∟∟content\_type|string|当前固定 application/gzip；客户端对存量字节仍须识别 gzip 魔数，不能仅据此假定所有历史内容均 gzip。|
|∟tos\_detail\_status|string|可选：available / not\_found / failed / not\_applicable。普通权限或非单 ID 时可省略；不存在或读取失败不使整个 Task 列表失败。|
|∟trace\_detail|object|开启 include\_trace / simplified / messages\_only 时返回共享场景的 \{data,meta\}；保留 meta 的来源、范围与完整度，不能与 /trace/query 的 DTO 混用。|
|∟trace\_detail\_status|string|共享场景详情状态：available / not\_found；依赖或读取失败保留错误，不把失败视为没有对话。|

#### 响应体示例

**成功示例**

以下为返回结构示例；v14 表示该示例命中的存量归档版本，不代表最大可读版本。

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "items": [
      {
        "task_id": "76991823008039229",
        "id_kind": "task",
        "task": {
          "row_source": "worker_task",
          "task_id": "76991823008039229",
          "assistant_id": "73385415154913921",
          "created_by": "guoyuze.123",
          "worker_session_id": "76991823007973693",
          "title": "阅读 helix 中 flux-insight 相关实现",
          "task_status": "interrupted",
          "work_mode": "coding",
          "worker_mode": "flux",
          "task_created_at": "2026-06-16 11:25:03",
          "task_updated_at": "2026-06-16 17:30:49",
          "task_is_completed": "0",
          "total_execution_duration_ms": "21946000",
          "agent_run_time_secs": "1480",
          "input_tokens": "2364454",
          "cached_tokens": "5213449",
          "output_tokens": "64853",
          "total_tokens": "8623729",
          "permission_request_count": "3",
          "interaction_count": "19",
          "dev_task_id": "2089192",
          "dev_task_url": "https://bits.bytedance.net/...",
          "release_ticket_id": "",
          "repo_path": "devinfra/helix"
        }
      }
    ],
    "page_info": {
      "limit": 50,
      "next_cursor": "",
      "has_more": false
    },
    "tos_detail": {
      "task_id": "76991823008039229",
      "version": "v14",
      "object_key": "flux-insight/snapshots/v14/76991823008039229.json.gz",
      "content_base64": "H4sIAAAAAAAA...（base64 编码的 gzip 内容，已省略）",
      "content_encoding": "base64",
      "content_type": "application/gzip"
    },
    "tos_detail_status": "available"
  }
}
```

**参数错误示例**

```json
{
  "code": 1001,
  "msg": "invalid_argument: task_id_list / worker_session_id_list 与 filters.filter_fields 不能同时为空",
  "data": {}
}
```

**鉴权失败示例**

```JSON
{
  "code": 2001,
  "msg": "unauthorized",
  "data": {}
}

```

#### 关键返回字段分组

|分组|典型字段|说明|
|---|---|---|
|任务标识|task\_id、id\_kind、row\_source、worker\_session\_id、task\_status、task\_is\_completed、task\_created\_at、task\_updated\_at|一行一个 task；id\_kind 标识 task\_id 是 task 还是 session；时间为 YYYY\-MM\-DD HH:MM:SS 字符串|
|人员与组织|created\_by、assistant\_id|归属人字段；普通权限下 created\_by 等归属人列会被脱敏（仅敏感数据权限保留）|
|分类|level\_1\_category、level\_2\_category、level\_3\_category、source\_platform|任务分类与来源平台，值来自 JSON 虚拟列|
|效率统计|input\_tokens、cached\_tokens、output\_tokens、total\_tokens、interaction\_count、agent\_run\_time\_secs、permission\_request\_count、total\_execution\_duration\_ms、task\_first\_response\_ms|task 维度累计值，均以字符串形式的整数返回|
|研发关联|dev\_task\_id、dev\_task\_url、bits\_space\_id、release\_ticket\_id、release\_ticket\_url、repo\_path|关联的开发任务 / 发布单 / 代码仓库信息，无关联时为空串|
|段级明细|related\_logic\_tasks（列表投影为瘦身版 related\_logic\_tasks\_lite）、related\_sessions|详情查询（单 id）返回完整段级/会话树；列表查询仅返回瘦身段级投影|
|TOS 快照|tos\_detail（version、object\_key、content\_base64、content\_encoding、content\_type）|敏感权限且单 ID 未开启 Trace 模式时可附带；单 Session 需唯一映射真实 Task。按 tos\_detail\_status 区分缺失与失败，Base64 解码后按实际字节与 version 解析。|
|共享 Trace|trace\_detail、trace\_detail\_status|单 ID \+ include\_trace / simplified / messages\_only；需要敏感权限，来源和完整度以 trace\_detail\.meta 为准。|

#### 字段使用约定

- tos\_detail 是 BFF 写入的任务/对话归档：flux\-insight/snapshots/vN/\{task\_id\}\.json\.gz，与 Worker 文件 manifest、worker\_file tar\.gz、历史 diff 的对象格式和 key 空间分别独立。

- 只有对象 NotFound 才向旧版本回退；权限、网络、配置或内容错误不通过降版本隐藏。可选归档失败时检查 tos\_detail\_status；not\_found 不等于任务不存在。

- Task 列表字段的字符串约定仅适用于 task 行；产物版本响应中的 message\_id 当前为 JSON number，JavaScript 调用方须使用保真大整数解析。

#### 错误码

|code|场景|msg / 说明|处理|
|---|---|---|---|
|0|成功|success|否|
|1001|缺查询条件、绑定失败、非法 ID 或 Trace 模式组合|invalid\_argument|修正请求|
|1002|不支持的过滤字段、字段类型/结构错误、条数超限|invalid filter field|修正请求|
|1003|算子/值非法、多字段 OR、JSON 虚拟列未搭配索引谓词|invalid filter content|修正请求|
|1004|limit 越界或 cursor 非法|invalid pagination|修正请求|
|1005|查询或共享场景响应超预算|query result too large|减小读取范围或分批|
|2001|JWT 缺失、无效、过期或主体类型不支持|unauthorized|刷新合法凭据|
|2002|无 IAM access 或共享 Trace 所需敏感权限|forbidden|先申请权限|
|2003|常规 OpenAPI 限流|rate\_limited|退避重试|
|3001|MySQL 或共享场景上游读取失败|upstream\_error|按错误分类重试|
|9000|IAM 调用失败或内部错误|internal\_error|可有限重试|
|AUTHZ\_\*|共享场景/最终授权的结构化错误|data\.error\.code / HTTP / retriable|以结构化错误为准|

可选 tos\_detail 不存在或读取失败通过 tos\_detail\_status=not\_found / failed 表达，Task 列表可继续 code=0；不再将其统一作为整个查询的 3003 / 3002 失败。共享 Trace 模式依赖读取失败仍返回实际错误。

#### 错误处理建议

|类别|处理方式|
|---|---|
|参数|1001–1004 先修请求；1005 改用 messages\_only / simplified 或 /task/trace 渐进读取。|
|权限|2001 更新 JWT；2002 检查 IAM access / access\_sensitive。AUTHZ\_\* 按结构化原因与 retriable 处理。|
|限流|常规 2003 指数退避并降低频率；含 AUTHZ\_\* 时不只按数字码重试。|
|上游|3001 / 9000 可有限重试；连续失败联系服务侧。|
|归档|not\_found 表示归档缺失，可继续使用列表；failed 表示读取失败，需要核查归档配置/权限/内容。|

## Trace 原文渐进读取 · POST /openapi/v1/task/trace

用途：任务原文过大时分批读取。此接口调用 BFF 共享场景，返回 \{code,msg,data:\{data,meta\}\}；它与仅 Mongo 的 /trace/query 使用不同返回模型。普通 OpenAPI 需要 IAM access \+ access\_sensitive；上线需 Backend 与 BFF 对应实现同时具备。

|参数|类型|规则|
|---|---|---|
|task\_id / session\_id|string|恰好一个；session\_id 仅表示 standalone 会话，不能用 worker\_session\_id 作同名别名；非 0 数字，长度 ≤20。|
|action|string|inventory / chunk / messages。inventory 不带 ticket/cursor；chunk/messages 必须带对应 ticket。|
|ticket|string|由 inventory 返回的 batch 或 session 票据，原样使用，长度 ≤24000。|
|cursor|string|上一页的游标，原样使用，长度 ≤24000；与原身份和票据绑定。|

```json
{
  "task_id": "91085349077485803",
  "action": "inventory"
}
```

先 inventory 获取索引与票据；按返回的 batch 票据读 chunk，按 session 票据读 messages；需要下一页时携带返回 cursor。票据过期、范围冲突或读取失败时保留错误并重新取 inventory，不更换 Task/Session 来凑齐正文。正文、采集完整度与来源按返回 data/meta 判断。

## 产物信息查询

以下产物接口共用 X\-Jwt\-Token / Content\-Type 请求头，均为 POST，当前只需要 IAM access。task\_id 和 worker\_session\_id 恰好传一个，使用正 int64 的数字字符串。为固定读取的会话，优先明确传 worker\_session\_id。

|数据|原始写入方|存储与读取位置|范围/时效|
|---|---|---|---|
|artifacts 文件|Helix Worker 同步 artifacts 工作目录|flux\-gateway：worker/manifests/\{session\_id\}\.json；worker/artifacts/\{session\_id\}/\{相对路径\}|最新已上传文件，异步更新，非历史版本|
|repos 文件|Helix Worker 打包 root session 下各仓库文件|flux\_backend\_tos\_credentials\.bucket（缺省 flux\-backend）：worker\_file/session\_\{session\_id\}，tar\.gz|仅 flux/changes 与 flux/\.local，不包含仓库全部改动源码|
|版本与 diff|Synalyzer 定时读取 Gateway 版本概览和区间 diff|hourly\.artifacts\.version\_index → Insight TOS 的 version\_index\.json / comparisons diff\.json|受采集配置、比较数量及上传成功与否限制|
|GUI 报告与截图|旧 Synalyzer 文件采集|hourly\.artifacts 中旧 manifest、test\_case、test\_report、screenshots 引用|旧全量采集当前暂停；可能只有既有数据|

Backend TCC 空间：flux\.insight\.config。新文件分别使用 flux\_gateway\_tos\_credentials、flux\_backend\_tos\_credentials；旧 Insight TOS 使用 tos\_credentials，桶名按实际配置，coze\-eval 仅是历史示例。Worker 主要在回合结束等同步点异步上传；旧版本采集代码每两小时北京时间 00:35、02:35、…、22:35 执行，任务筛选、配置与失败会影响实际时效。

当前实现边界：Synalyzer Collect 已暂停 collectFullArtifacts，旧报告/截图采集函数也没有在该主流程调用；版本采集继续受配置控制。因此新 raw 的文件存在，不保证旧 GUI 接口有数据。versions 当前不填充 comparisons / version\_index\_url，客户端不能用 versions\.comparisons 枚举可用 diff 区间；diff 返回的 diff\_url 目前为空字符串。此处记录源码现状，不将缺口描述成已经修复的能力。

### 查询已上传的产物文件清单

POST /openapi/v1/task/changed/artifacts

直接传 worker\_session\_id 可定位 TOS，无需 hourly 行。传 task\_id 时优先读取 hourly 中 updated\_at DESC LIMIT 1 的记录，无行才回退 task insight；这不是最大 Session ID，也不保证是当前运行 Session。

```json
{
  "worker_session_id": "91085349077420267"
}
```

|返回字段|类型|含义|
|---|---|---|
|task\_id|string，可省略|Task 定位时返回；只传 session 的 IAM 读取不会查表回填 Task。|
|worker\_session\_id / session\_id|string|本次读取的会话身份。|
|updated\_at|number|两来源最近更新时间的最大值，毫秒；不是共同版本或一致快照证明。|
|manifest\_url|string|Gateway manifest URL；只有压缩包时为 ""。|
|worker\_file\_url / worker\_file\_updated\_at|string / number，可省略|Worker tar\.gz URL 与 TOS LastModified 毫秒时间。|
|file\_count / files|number / array|合并后实际返回的文件数与列表；文件含 path、scope、size、sha256。size=0 等空值字段可能省略。|

当前不返回 version\_id / truncated，也不填充文件 mime\_type / skip\_reason。Gateway 文件路径补 artifacts/ 前缀，压缩包文件保留 repos/\.\.\.。只有明确某来源 NotFound 才允许返回另一来源；其他来源读取失败不隐藏成部分成功。无两来源时返回错误。清单不包含链接类产物，非法 manifest 项会被跳过，不代表全仓库采集完整。

### 获取某个文件内容

POST /openapi/v1/task/artifacts/raw

```json
{
  "worker_session_id": "91085349077420267",
  "path": "artifacts/specs/tech/tech-spec.md"
}
```

path 必填，优先使用文件清单实际返回的 path。artifacts/\.\.\. 或其 manifest 相对路径读取 flux\-gateway 文件；repos/\.\.\. 读取 Worker tar\.gz 文件。拒绝绝对路径、目录穿越与未规范化路径。任何非 null version\_id（包括 0）都会被拒绝：新存储只提供当前已上传内容，不能用版本列表中的 ID 读历史文件。

成功返回文件原始字节，Content\-Type 根据扩展名推断，未知为 application/octet\-stream；失败返回错误 JSON。响应头包含 X\-Artifact\-Worker\-Session\-ID、X\-Artifact\-Path、X\-Artifact\-Tos\-Key、X\-Artifact\-SHA256、X\-Artifact\-Size；有 TaskID 时才有 X\-Artifact\-Task\-ID；新实现没有 X\-Artifact\-Version\-ID。

### 读取已采集的版本信息

POST /openapi/v1/task/artifacts/versions

```json
{
  "worker_session_id": "91085349077420267"
}
```

要求 hourly 行及 artifacts\.version\_index 已采集。只传 task\_id 命中多条 Session 行时返回 1001，须显式选 worker\_session\_id，不自动取最新。versions 包含有 conversation\_version 的快照，另保留没有该字段的最新快照；不承诺列出每个内部版本。version\_id 为物理快照号，conversation\_version 为主对话版本，编号不等同。

|返回字段|含义|
|---|---|
|task\_id / worker\_session\_id|字符串身份。|
|latest\_version\_id|hourly artifacts 中最近采集的版本号。|
|versions\[\]|version\_id、message\_id、created\_at，以及可选 message、conversation\_version、desc。message\_id 当前为 JSON number，17 位 ID 需保真解析。|
|has\_full\_snapshot|仅表示旧 artifacts\_manifest URL 非空，不验证对象存在，更不代表任意历史版本文件可读。|
|comparisons / comparisons\_truncated|当前 comparisons 未赋值，返回 null；comparisons\_truncated 保留采集范围被限制的事实。|

### 读取已采集区间的 diff

POST /openapi/v1/task/artifacts/version\-diff

|参数|规则|
|---|---|
|task\_id / worker\_session\_id|恰好一个；需要对应 hourly 行，多 Session 的 Task 必须明确选择。|
|from\_version\_id \+ to\_version\_id|完整物理快照区间；0 是合法基线。|
|from\_conversation\_version \+ to\_conversation\_version|也可完整提供主对话区间；两组完整提供时物理版本组优先。|

```json
{
  "worker_session_id": "91085349077420267",
  "from_conversation_version": 0,
  "to_conversation_version": 1
}
```

返回所匹配区间的两套版本编号、from/to\_conversation\_desc、changed\_file\_count 和 diff JSON 原文；diff\_url 当前为空字符串。仅在 version\_index\.comparisons 中有匹配项且采集 diff\_url 非空时可读取，不请求 Gateway 在线计算任意区间。缺比较或空 URL 返回 artifact\-version\-diff\-not\-found，不等于零变更；不提供单文件 path 过滤。

### GUI 测试用例结果

POST /openapi/v1/task/artifacts/gui\-test/case\-result

```json
{
  "worker_session_id": "91085349077420267"
}
```

需要旧 hourly 采集数据。先读取 artifacts\_manifest 中全部可下载的 test\_case\.html；没有结果再读 test\_report\.html；缺 manifest 或无报告匹配才退旧 test\_case / test\_report URL。manifest/文件读取或解析失败直接报错，不隐藏成旧 URL 回退成功。

结果位于 data\.items\[\]\.case\_result，来自 HTML 的 \<script id="report\-data" type="application/json"\> JSON 内的 caseResult；source 为 manifest:test\_case、manifest:test\_report、test\_case 或 test\_report。报告跨 artifacts/repos 按父目录名与文件名去重，保留 paths。只传 Task 命中多 Session 时须明确选择。旧全量采集暂停的可用性边界见本节开头。

### GUI 旧采集截图

POST /openapi/v1/task/artifacts/gui\-test/screenshots

```json
{
  "worker_session_id": "91085349077420267",
  "path": "TC-HOME-001-01-F001"
}
```

需要旧 hourly\.artifacts\.screenshots。path 为匹配 URL 的子串，下载首个命中对象；成功返回图片字节，失败返回错误 JSON。若要读取新 Worker 清单中的图片，应使用该清单返回的完整 path 调 raw。

### 产物错误处理

|code / 原因|含义与处理|
|---|---|
|1001|定位参数非法、Task 多 Session、路径未命中、缺采集数据等。按 msg 修请求或确认采集，不能当成空成功。|
|artifact\-version\-index\-not\-collected|旧 version\_index 未采集。|
|artifact\-version\-diff\-not\-found|没有该比较区间，或 diff\_url 空；可能未采集、被范围限制或采集失败。|
|2001 / 2002 / 2003|常规 JWT / IAM / 限流错误；带 AUTHZ\_\* 时按结构化错误处理。|
|3001 / 3002 / 9000|数据库、TOS、解析、完整性或内部依赖失败；保留错误并有限重试，不换来源声称完整。|

## Trace 查询 · POST /openapi/v1/trace/query

### 基本信息

|项目|说明|
|---|---|
|HTTP URL|https://\{domain\}/openapi/v1/trace/query|
|HTTP Method|POST|
|频控限制|默认 10 次/s；接口 × 服务实例 × 已认证主体，按部署配置调整|

### 请求消息

#### 请求头

|名称|类型|必填|描述|
|---|---|---|---|
|X\-Jwt\-Token|string|是|调用凭证 token|
|Content\-Type|string|是|application/json|
|X\-Flux\-Trace\-Contract|string|否，推荐 2|2 返回 trace\-read\-model\.v2；缺省/1 为旧 v1。只能单个值 1 或 2。|

#### 请求参数

|名称|类型|必填|描述|
|---|---|---|---|
|task\_id|string|否，task\_id 与 worker\_session\_id 选一必填|1～64 位数字字符串；两标识同时传时 Task 优先，Session 包括格式校验均被忽略。先解析展示主 Session，Mongo 按 task\_id 定界，可覆盖该 Task 多物理会话。|
|worker\_session\_id|string|否，task\_id 与 worker\_session\_id 选一必填|仅在 task\_id 为空时使用；作为独立物理 flux\_session\_id 查询范围，不能由共享 workspace 推断唯一 Task。|
|include\_raw\_spans|boolean|否|是否返回脱敏后的原始 Span，默认 false。|
|compress|boolean|否|是否尝试标准 HTTP gzip，默认 true；显式传 false 时不压缩。|

#### 请求体示例

```JSON
{
  "task_id": "91226152819066960",
  "include_raw_spans": false,
  "compress": true
}
```

#### 查询行为说明

**查询标识**

task\_id 与 worker\_session\_id 至少提供一个；同时提供时 Task 优先。Task 通过 Gateway 解析响应展示用的主 Worker Session，但 Mongo 真正查询范围为 task\_id；独立 Session 才按物理 flux\_session\_id 查询。此接口只读取 Mongo spans，不回退 Fornax，也不使用产物文件存储。

响应合同：推荐 X\-Flux\-Trace\-Contract: 2，返回 trace\-read\-model\.v2；缺省或 1 选旧 v1。源数据的未知角色、缺失时间或未知时长无法被 v1 如实表示时，返回 code=3005、reason\_code=TRACE\_CONTRACT\_REQUIRED、required\_contract=2；改合同头 2 重试，不能把它直接判为 Span 损坏。非法/重复合同头为 1001 \+ TRACE\_CONTRACT\_INVALID。外部 OpenAPI 的这些合同错误仍用 HTTP 200。

```bash
curl --compressed -X POST "https://flux-insight.byted.org/openapi/v1/trace/query" \
  -H "Content-Type: application/json" \
  -H "X-Jwt-Token: <你的jwt token>" \
  -H "X-Flux-Trace-Contract: 2" \
  -d '{"task_id":"91226152819066960","include_raw_spans":false,"compress":true}'
```

**响应压缩**

查询成功且存在数据时默认尝试 HTTP gzip，只有压缩后体积更小时才返回 Content\-Encoding: gzip；compress=false、无压缩收益或错误响应时返回未压缩 JSON。

### 响应体

> 字段详细说明见 [\[OpenAPI\] Flux Insight 开放接口说明（含 Trace 查询）](https://bytedance.larkoffice.com/docx/CX6pdPrlqo7nCUxaq5qcG40Mn5c)
> 
> 

|名称|类型|描述|
|---|---|---|
|code|int|错误码，0 表示成功，非 0 表示失败|
|msg|string|错误信息描述；成功时固定为 success|
|data|object|成功时返回完整 Trace；失败时返回 \{\}|
|∟schema\_version|string|由合同头选择：2 为 trace\-read\-model\.v2；缺省/1 为兼容 v1，不能表示时返回合同升级错误。|
|∟task\_id|string|Flux 任务 ID；按 Session 查询且无法唯一回填时为空|
|∟worker\_session\_id|string|Task 查询为展示用的主 Session 投影，不是 Mongo 查询谓词；独立 Session 查询时才是实际物理会话范围。|
|∟meta|object|source、complete、generated\_at、time\_range、counts、schema\_versions、redaction、limits|
|∟summary|object|status、duration\_ms、duration\_source、token\_usage、models、origins、step\_kind\_counts、anomaly\_counts|
|∟sessions|Array|主 Agent 与 SubAgent 的会话、Turn 和执行步骤|
|∟anomalies|Array|Trace 组装过程中识别出的结构化异常|
|∟raw\_spans|Array|仅 include\_raw\_spans=true 时返回脱敏后的原始 Span|

#### 响应体示例

**成功示例**

以下结构示例对应请求头 X\-Flux\-Trace\-Contract: 2。

```json
{
  "code": 0,
  "msg": "success",
  "data": {
    "schema_version": "trace-read-model.v2",
    "task_id": "91226152819066960",
    "worker_session_id": "91226152818935808",
    "meta": {
      "source": "mongodb",
      "complete": true
    },
    "summary": {
      "status": "success",
      "duration_ms": 1000,
      "token_usage": {}
    },
    "sessions": [],
    "anomalies": []
  }
}
```

**参数错误示例**

```JSON
{
  "code": 1001,
  "msg": "invalid_argument",
  "data": {}
}
```

**鉴权失败示例**

```JSON
{
  "code": 2001,
  "msg": "unauthorized",
  "data": {}
}
```

#### 关键返回字段分组

|分组|典型字段|说明|
|---|---|---|
|元信息|meta\.source、complete、generated\_at、time\_range、counts（spans、traces、sessions、turns、root\_steps、steps、model\_calls、tool\_calls、anomalies）、schema\_versions、redaction（level、redacted、field\_count）、limits（span\_limit、input\_bytes、response\_bytes、elapsed\_ms）|数据源、完整性、时间范围、数量、脱敏和容量信息；source 固定为 mongodb|
|汇总|summary\.status、duration\_ms、duration\_source、token\_usage、models（name、calls、token\_usage）、origins、step\_kind\_counts、anomaly\_counts（total、error、warning、notice）|任务状态、耗时、Token、模型、来源、步骤和异常汇总|
|Token|input、cached\_input、non\_cached\_input、cache\_creation\_input、output、reasoning\_output、total、known、total\_known、total\_source|Token 消耗与完整性；total\_known 表示总量是否完整|
|Session|id、parent\_session\_id、role、origin、title、status、time\_range、trace\_ids、relation、summary、turns|主 Agent 与 SubAgent 会话；SubAgent 通过 parent\_session\_id 关联父会话|
|Session 汇总|duration\_ms、duration\_source、turns、user\_messages、assistant\_messages、tool\_calls、model\_calls、token\_usage、anomalies|单个 Session 的耗时、消息、调用和异常汇总|
|Turn|id、sequence、source\_turn\_id、message\_id、user\_message\_id、assistant\_message\_id、history\_message\_ids、trace\_ids、origin、title、label、status、timing、model、mode、token\_usage、model\_calls、proxy\_calls、steps、anomalies|一次用户输入及其完整处理过程|
|Turn 耗时|started\_at、ended\_at、duration\_ms、ttft\_ms、duration\_source|Turn 开始、结束、总耗时和首 Token 耗时|
|Step|id、sequence、kind、origin、title、summary、search\_text、status、model\_call\_id、timing、decision\_group、payload、result、children、evidence、anomalies|用户输入、模型思考与回复、工具调用及 SubAgent 等执行步骤；children 为递归子步骤|
|Step 耗时|started\_at、ended\_at、duration\_ms、duration\_source、latency\.total\_ms、execution\_ms、permission\_wait\_ms、decision\_group\.index、evidence\_level|步骤总耗时、执行耗时和权限等待耗时|
|模型调用|id、sequence、trace\_id、span\_id、logid、message\_id、started\_at、duration\_ms、ttft\_ms、duration\_source、model、step\_index、token\_usage、token\_usage\_known、evidence|模型请求、耗时、Token 与证据|
|代理调用|call\_count、retries、max\_retries、total\_duration\_ms、max\_call\_ms、first\_token\_latency\_ms、tokens、cost\_usd、http\_status\_code、provider、calls|模型代理调用汇总及重试明细|
|代理尝试|id、sequence、span\_id、started\_at、duration\_ms、tokens、cost\_usd、deployment、status、is\_retry、attempt\_index、logid、message\_id、evidence|每次模型代理请求的状态、耗时和成本|
|工具结果|call\_id、output、raw\_output、is\_error、status、exit\_code、duration\_ms、duration\_source、chunk\_id、truncated、output\_policy（kind、omitted\_bytes、reason）|工具输出、错误、耗时和截断策略|
|证据与异常|Evidence：level、trace\_id、span\_id、source\_span\_ids、relation\_rule、note；Anomaly：code、severity、scope、entity\_id、message、evidence|字段来源、关联规则和组装异常|
|原始 Span|schema\_version、trace\_id、span\_id、parent\_span\_id、operation、outcome、started\_at、ended\_at、duration\_ms、received\_at、payload、redaction（redacted、field\_count、paths）|include\_raw\_spans=true 时返回；payload 已进行权限控制和递归脱敏|

#### 字段使用约定

- v2 缺失时间字段可省略，未知耗时可为 null；不要补年份 0001 或把 unknown 改成 0/成功。

- meta\.complete 表示本次来源读取合同，不代表任务已完成、保留全部历史或所有外部系统数据已到齐；状态、异常、Token 完整度分别按各字段判断。

- Task 范围可覆盖同 Task 的多个物理会话，但不能扩展到共享 workspace 的兄弟 Task。Task 主 Session 字段是展示投影。

#### 错误码

|code|场景|msg 示例|是否可重试|
|---|---|---|---|
|0|成功|success|否|
|1001|缺标识、绑定/格式非法或合同头非法/重复|invalid\_argument；合同错误附 TRACE\_CONTRACT\_INVALID|否|
|1005|Span 数、输入 BSON 或响应 JSON 超限|query result too large, please narrow task\_id\_list or filters|否|
|2001|JWT 缺失、无效或过期|unauthorized|否|
|2002|无调用权限|forbidden|否|
|2003|触发限流|rate\_limited|是|
|3001|Task 解析或 MongoDB 上游错误|upstream\_error|是|
|3004|指定 Session 无 Span|trace\_not\_found|否|
|3005|Span/范围不完整，或旧 v1 无法表示合法稀疏数据|trace\_incomplete；合同升级附 TRACE\_CONTRACT\_REQUIRED / required\_contract=2|合同升级先改头 2，其他按原因排查|
|3006|查询超时|trace\_query\_timeout|是|
|9000|内部错误|internal\_error|是|

#### 错误处理建议

|错误类别|包含错误码|推荐处理策略|
|---|---|---|
|参数错误|1001、1005|不建议直接重试。1001 请修正查询参数；1005 请关闭 raw spans 后重试，仍超限时联系服务方。|
|鉴权/权限|2001、2002|不建议重试。2001 请重新申请 JWT；2002 请确认调用权限。|
|限流|2003|可重试。建议指数退避（1s → 2s → 4s），最多重试 3 次；持续限流时降低调用 QPS。|
|上游依赖|3001、3006、9000|可重试。首次失败后等待 1～2 秒重试一次，连续失败时告警并转人工排查。|
|数据缺失|3004、3005|3004 核对身份/采集；3005 若 reason\_code=TRACE\_CONTRACT\_REQUIRED，则加 X\-Flux\-Trace\-Contract: 2 重试；其他不完整原因联系服务侧，不能将失败当成空 Trace。|

# 变更记录

|版本 / 变更|日期|变更说明|
|---|---|---|
|源码合同核对与接口总览|2026\-10\-29|按 Backend 50942ae / Helix b792f3c425 更新说明：Worker 新文件来源与范围、旧版本/GUI 依赖与缺口、Task lookahead 分页及归档状态、共享 Trace 模式与渐进读取、Mongo Task 定界和 v2 合同。本次为文档更新，未核验生产部署或修改服务。|
|换表 \+ keyset 分页 \+ IAM 鉴权|—|数据源从数仓 OneService 换为直连 MySQL ios\_arch\.flux\_task\_insight，一行 = 一个 task；分页由 page/page\_size 改为 keyset 游标（limit \+ cursor，去掉 total）；鉴权改为 IAM 权限校验（access / access\_sensitive 两级），普通权限对归属人与敏感列脱敏；过滤字段调整（username→created\_by、session\_id→worker\_session\_id，下线 leader\_name/dept\_full\_path，新增 task\_status/row\_source/task\_is\_completed/updated\_at 及 level\_\*\_category/source\_platform JSON 虚拟列）；请求新增 worker\_session\_id\_list；响应 task 改为按 DB 列白名单动态透出的 map 并新增 id\_kind。|
|任务维度聚合改造|7\.15|（历史版本，已被上一行取代）返回结果按 task\_id 聚合为一行；下线 token\_usage、repo\_path、mr\_ids 及 7 个计算字段；新增 conversation\_ids。|
|新增 Trace 查询 OpenAPI|9\.29|新增 POST /openapi/v1/trace/query，支持按 task\_id 或 worker\_session\_id 查询 MongoDB Trace；补充会话、Turn、Step、SubAgent 递归执行详情、模型与代理调用、工具结果、证据、Token 消耗、耗时、异常与可选 raw spans 字段；明确 task\_id 优先级和标准 HTTP gzip 压缩规则。|

---

# 联系与支持

使用中遇到问题，或想获取 Flux Insight 的最新动态？欢迎扫码加入用户群，我们会在群内答疑并同步接口变更，如有任何问题可联系 @刘苏锐（liusurui\.567@bytedance\.com）。

![flux\-insight\-user\-group\-qr\.png](图片和附件/flux-insight-user-group-qr.png)



